#### How to import->

1. create a database on your localhost named as `bookstore`;
2. then copy the repo to your htdocs folder and visit using this URL on your localhost http://localhost/Bookstore/
3. then import the sql (which is inside the sql directory) file on phpmyadmin

ADMIN:-
Email: admin
Password: admin123
