      	<hr>

      	<footer class="fixed-bottom bg-dark bg-gradient border py-3 px-2">
			<div class="container">
				<div class="d-flex justify-content-between">
					<div class="">
						<a href="index.php" class="text-decoration-none text-muted fw-bold"> Book Store </a>
					</div>
					
					
				</div>
			</div>
      	</footer>
		<div class="clear-fix py-4"></div>
    </div> <!-- /container -->

  </body>
</html>